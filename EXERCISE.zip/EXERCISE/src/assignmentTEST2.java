import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class assignmentTEST2 { //ouput full job error



        public static void main(String[] args) throws FileNotFoundException {
            int lines = 0;

            System.out.println("Error made by the user :");

            Scanner inputStream = new Scanner(new FileInputStream("C:\\FOP_ASSIGNMENT_FILE\\extracted_log.txt"));

            while (inputStream.hasNextLine()) {


                String line = inputStream.nextLine();
                //String[] arrOfStr = line.split(" ");

                if (line.contains("error: This association")) {
                    //for (int i = 0; i < 1; i++) {

                        // System.out.print(arrOfStr[i]+" ");
                       // System.out.println(arrOfStr[0].concat(arrOfStr[5])+" ");
                    System.out.println(line);

                        lines++;


                    }


                }
            inputStream.close();
            System.out.println("Total number of jobs causing error : " + lines);
        }

            }



