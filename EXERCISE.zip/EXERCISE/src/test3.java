

import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

    public class test3 {
        public static void main(String[] args) {

            int jobCreated = 0;
            int jobEnded = 0;
            Scanner userInput = new Scanner (System.in);
            System.out.print("Enter Start Year: ");
            int s_year = userInput.nextInt();
            System.out.print("Enter Start Month: ");
            int s_month = userInput.nextInt();
            System.out.print("Enter Start Day: ");
            int s_day = userInput.nextInt();
            System.out.print("Enter Start Hour: ");
            int s_hour = userInput.nextInt();
            System.out.print("Enter Start Minute: ");
            int s_min = userInput.nextInt();
            System.out.print("Enter Start Seconds: ");
            int s_secs = userInput.nextInt();

            System.out.print("Enter End Year: ");
            int e_year = userInput.nextInt();
            System.out.print("Enter End Month: ");
            int e_month = userInput.nextInt();
            System.out.print("Enter End Day: ");
            int e_day = userInput.nextInt();
            System.out.print("Enter End Hour: ");
            int e_hour = userInput.nextInt();
            System.out.print("Enter End Minute: ");
            int e_min = userInput.nextInt();
            System.out.print("Enter End Seconds: ");
            int e_secs = userInput.nextInt();

            LocalDateTime startTime = LocalDateTime.of(s_year, s_month, s_day, s_hour, s_min, s_secs);
            LocalDateTime endTime = LocalDateTime.of(e_year, e_month, e_day, e_hour, e_min, e_secs);

            try (Scanner fileInput = new Scanner(new FileReader("C:\\FOP_ASSIGNMENT_FILE\\extracted_log.txt"))) {
                while (fileInput.hasNext()) {
                    String line = fileInput.nextLine();

                    String timestampString = line.substring(1, line.indexOf(']'));
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");
                    LocalDateTime timestamp = LocalDateTime.parse(timestampString, formatter);

                    if (line.contains("Allocate")) {
                        if (timestamp.isAfter(startTime) && timestamp.isBefore(endTime)) {
                            jobCreated++;
                            //System.out.println("job created count: " + jobCreated);
                        }
                    } else if (line.contains("_job_complete")) {
                        if (timestamp.isAfter(startTime) && timestamp.isBefore(endTime)){
                            jobEnded++;
                            //System.out.println("job ended count: " + jobEnded);
                        }
                    }
                }
                System.out.println("----------------------------------------------------------------------------------");
                System.out.println("Showing data within date time range of: " + startTime + " to " + endTime);
            } catch (IOException e) {
                e.printStackTrace();
            }
            String [][] array = new String [2][2];
            array [0][0] = "Number of jobs created";
            array [1][0] = "Number of jobs ended";
            array [0][1] = "\t" + Integer.toString(jobCreated);
            array [1][1] = "\t" + Integer.toString(jobEnded);

            for (int i = 0; i<2 ; i++){
                for (int j=0; j<2; j++){
                    System.out.print(array[i][j] + " ");
                }
                System.out.println();
            }
        }
    }


