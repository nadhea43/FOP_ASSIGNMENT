import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class test4 {
    public static void main(String[]args) throws FileNotFoundException {
        int jobCreated = 0;
        int jobEnded = 0;
        int error = 0;

        Scanner userInput = new Scanner (System.in);
        System.out.print("Enter Start Year: ");
        int s_year = userInput.nextInt();
        System.out.print("Enter Start Month: ");
        int s_month = userInput.nextInt();
        System.out.print("Enter Start Day: ");
        int s_day = userInput.nextInt();
        System.out.print("Enter Start Hour: ");
        int s_hour = userInput.nextInt();
        System.out.print("Enter Start Minute: ");
        int s_min = userInput.nextInt();
        System.out.print("Enter Start Seconds: ");
        int s_secs = userInput.nextInt();

        System.out.print("Enter End Year: ");
        int e_year = userInput.nextInt();
        System.out.print("Enter End Month: ");
        int e_month = userInput.nextInt();
        System.out.print("Enter End Day: ");
        int e_day = userInput.nextInt();
        System.out.print("Enter End Hour: ");
        int e_hour = userInput.nextInt();
        System.out.print("Enter End Minute: ");
        int e_min = userInput.nextInt();
        System.out.print("Enter End Seconds: ");
        int e_secs = userInput.nextInt();

        LocalDateTime StartDate = LocalDateTime.of(s_year,s_month,s_day,s_hour,s_min,s_secs);
        LocalDateTime EndDate= LocalDateTime.of(e_year, e_month, e_day, e_hour, e_min, e_secs);

        Scanner inputStream = new Scanner(new FileReader("C:\\FOP_ASSIGNMENT_FILE\\extracted_log.txt"));

        while (inputStream.hasNextLine()) {
            String  line = inputStream.nextLine();




            String Time = line.substring(1,line.indexOf(']'));
            DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd 'T' HH:mm:ss:SSS");
            LocalDateTime TimeInterval = LocalDateTime.parse(Time, format);

            if(line.contains("error")){
                if(TimeInterval.isAfter(StartDate) && TimeInterval.isBefore(EndDate)){
                  error++;
                }

            }





            //if(line.contains("Allocate")){
               // if(TimeInterval.isAfter(StartDate) && TimeInterval.isBefore(EndDate) ){

               // }



                }
            }

            }
















