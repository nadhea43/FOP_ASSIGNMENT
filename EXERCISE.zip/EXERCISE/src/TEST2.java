import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class TEST2 {
    public static void main(String[] args) throws FileNotFoundException {
        int lines = 0;

        System.out.println("Error made by the user :");

        Scanner inputStream = new Scanner(new FileInputStream("C:\\FOP_ASSIGNMENT_FILE\\extracted_log.txt"));

        while (inputStream.hasNextLine()) {


            String line = inputStream.nextLine();
            String[] arrOfStr = line.split(" ");


            for (int i = 0; i < arrOfStr.length; i++) {

                if (line.contains("error: This association")) {

                    System.out.print(arrOfStr[i]+" ");

                    lines++;


                }

            }

        }
            inputStream.close();
            System.out.println("Total number of jobs causing error : " + lines);
        }
    }




    // read each line and
    // count number of lines
    /*  while(sc.hasNextLine()) {
        sc.nextLine();
        count++;
    }
      System.out.println("Total Number of Lines: " + count);

    // close scanner
      sc.close();*/


/*int count=0;
           for (int i = 0; i < arrOfStr.length; i++) {
               String jobID = "JobId";
               if(arrOfStr[i].equals(jobID)){
                   count++;
               }

            }
            System.out.println(count);
        }*/







