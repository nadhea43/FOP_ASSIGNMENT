import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class NEW01 {
    public static void main(String[]args){
        /*Scanner userInput = new Scanner (System.in);
        System.out.print("Enter Start Year: ");
        int s_year = userInput.nextInt();
        System.out.print("Enter Start Month: ");
        int s_month = userInput.nextInt();
        System.out.print("Enter Start Day: ");
        int s_day = userInput.nextInt();
        System.out.print("Enter Start Hour: ");
        int s_hour = userInput.nextInt();
        System.out.print("Enter Start Minute: ");
        int s_min = userInput.nextInt();
        System.out.print("Enter Start Seconds: ");
        int s_secs = userInput.nextInt();

        System.out.print("Enter End Year: ");
        int e_year = userInput.nextInt();
        System.out.print("Enter End Month: ");
        int e_month = userInput.nextInt();
        System.out.print("Enter End Day: ");
        int e_day = userInput.nextInt();
        System.out.print("Enter End Hour: ");
        int e_hour = userInput.nextInt();
        System.out.print("Enter End Minute: ");
        int e_min = userInput.nextInt();
        System.out.print("Enter End Seconds: ");
        int e_secs = userInput.nextInt();

        LocalDateTime StartDate = LocalDateTime.of(s_year,s_month,s_day,s_hour,s_min,s_secs);
        LocalDateTime EndDate= LocalDateTime.of(e_year, e_month, e_day, e_hour, e_min, e_secs);

       String Time = line.substring(0,']');
        DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd 'T' HH:mm:ss:SSS");
        LocalDateTime TimeInterval = LocalDateTime.parse(StartDate, format);*/
    }
}
