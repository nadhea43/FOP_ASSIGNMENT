
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
int sum=0 ;
        System.out.print("Enter an integer: ");
        int n = input.nextInt();

        for(int i=0 ; i<n ;i++){
            int term=0;
            for(int j=1 ; j<=i+1 ; j++){
                term+=j;
            }
            System.out.println(term);
            sum+=term;
        }
        System.out.println(sum);

    }
}