import java.util.Random;
import java.util.Scanner;

public class exercise02 {

        public static void main(String[] args) {
// TODO code application logic here


            Scanner input = new Scanner(System.in);
            Random ran = new Random();

            int num1,num2;
            int sum=0;
            char operand;

            num1 = ran.nextInt(12)+2;
            num2 = ran.nextInt(12)+2;
            System.out.println(num1);
            System.out.println(num2);

            System.out.println("Enter the operand:");
            operand = input.next().charAt(0);



            switch (operand)
            {
                case '+':
                    sum= num1+num2;
                    break;
                case '-':
                    sum= num1-num2;
                    break;
                case '*':
                    sum=num1*num2;
                    break;
                case '/':
                    sum=num1/num2;
                    break;
                case '%':
                    sum=num1%num2;
                    break;
                default :

            }
            System.out.println(num1+" "+operand+" "+num2+" = "+sum);

        }

    }



