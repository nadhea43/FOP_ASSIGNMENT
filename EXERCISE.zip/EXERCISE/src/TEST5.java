import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class TEST5 {
    public static void main(String[] args) throws FileNotFoundException {
        int lines = 0;

        System.out.println("Error made by the user :");

        Scanner inputStream = new Scanner(new FileInputStream("C:\\FOP_ASSIGNMENT_FILE\\extracted_log.txt"));

        while (inputStream.hasNextLine()) {

            String line = inputStream.nextLine();
            String[] arrOfStr = line.split(" ");

            for (int i = 0; i < arrOfStr.length; i++) {
                if (line.contains("error: This association")) {

                    System.out.print(arrOfStr[i] + " ");
                    lines++;

                }
        System.out.println(lines);
            }


            //System.out.println();

        }
        inputStream.close();
        System.out.println("Total number of jobs causing error : " + lines);
    }}


