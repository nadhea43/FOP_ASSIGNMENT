import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class TRY {
    public static void main(String[] args)  throws FileNotFoundException, IOException{

        Scanner inputStream = new Scanner(new FileInputStream("C:\\FOP_ASSIGNMENT_FILE\\extracted_log.txt"));


while(inputStream.hasNextLine()){

    System.out.println(inputStream.nextLine());

    String line = inputStream.nextLine();
   String a[] = line.split(" ");
    for (int i = 0 ; i<a.length ; i++){
        System.out.print(a[i]);
        System.out.println("");
    }
    /*ystem.out.println("/n/n");
    inputStream.nextLine();
    String searchkey ="JobId";
    for(int i=0 ; i<a.length ; i++){
        if(a[i] == searchkey){
            String jobID = searchkey;
            System.out.println(jobID);
        }
    }*/



}



    }
}
