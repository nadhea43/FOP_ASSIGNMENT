import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class assignment {

        // add throws to main method to handle exceptions
        public static void main(String[] args) throws IOException {
            List<String> listOfStrings = new ArrayList<String>();
            int total = 0;
            int j = 0;

            // load the data from file
            listOfStrings = Files.readAllLines(Paths.get("C:\\FOP_ASSIGNMENT_FILE\\extracted_log.txt"));

            // convert arraylist to array
            String[] array = listOfStrings.toArray(new String[0]);

            String name2[] = new String[143];

            System.out.printf("%10s%27S%30s\n","NAME OF USERS","|","NUMBER OF ERRORS");
            System.out.println("----------------------------------------------------------------------------");
            // print each line of string in array
            for (String eachString : array) {
                String[] arr = eachString.split(" "); //array in one line

                if(eachString.contains("error: This association")){
                    total++;
                    Name(arr);
                    if (j < 143){
                        name2[j] = Name(arr); //putting name in array
                        j++;
                    }
                }
            }
            counter(name2,total);
            System.out.println("------------------------------------------------------------------------");
            System.out.printf("%-20s%50d\n","TOTAL", total);


        }

        public static String Name(String arr[]){
            String[] user = arr[5].split(""); //make array for letters
            int m = user.length - 2;
            String name = arr[5].substring(6,m);
            return name;

        }
        public static void counter(String name2[], int n){
            boolean visited[] = new boolean[n];

            Arrays.fill(visited, false);

            for (int i = 0; i < n; i++){
                if (visited[i] == true){
                    continue;
                }
                int count = 1;
                for (int k = i + 1; k < n; k++){
                    if(name2[i].equals(name2[k])){
                        visited[k] = true;
                        count++;
                    }
                }
                System.out.printf("%-20s%20s%30d\n",name2[i],"|",count);
            }
        }
    }
