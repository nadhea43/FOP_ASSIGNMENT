import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class NEW02 {
    public static void main(String[] args) throws FileNotFoundException {
        int lines = 0;

        System.out.println("Error made by the user :");

        Scanner inputStream = new Scanner(new FileInputStream("C:\\FOP_ASSIGNMENT_FILE\\extracted_log.txt"));

        while (inputStream.hasNextLine()) {


            String line = inputStream.nextLine();
            String[] arrOfStr = line.split(" ");

            if (line.contains("error: This association")) {
            for (int i = 0; i < arrOfStr.length; i++) {

                    // System.out.print(arrOfStr[i]+" ");
                    System.out.println(arrOfStr[0].concat(arrOfStr[5])+" ");

                    lines++;


                }
                System.out.println();

            }

        }
        inputStream.close();
        System.out.println("Total number of jobs causing error : " + lines);
    }
}