import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class assignmentTEST3 { //print user who caused error

        public static void main(String[] args) throws FileNotFoundException {
            String user = " ";

            System.out.println("Users who caused error : ");

            Scanner input = new Scanner(new FileInputStream("C:\\FOP_ASSIGNMENT_FILE\\extracted_log.txt"));
            while (input.hasNextLine()) {

                String line = input.nextLine();
                String[] arr = line.split(" ");

                if (line.contains("error: This association")) {
                    while(!arr[5].equals(user)){
                        user = arr[5];
                        System.out.println(user);
                    }
                }
            }
            input.close();
        }
    }

