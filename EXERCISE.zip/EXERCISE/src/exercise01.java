
import java.util.Scanner;
import java.util.Random;
public class exercise01 {
  public static void main(String[]args){
  /*Random ran = new Random();
  int P1ROLL,P2ROLL,SCORE1=0,SCORE2=0;
  for(int i=0,j=1 ;i<=SCORE1,j<=SCORE2 ; i++,j++ )
    while (true) {
      P1ROLL = ran.nextInt(6) + 1;
      System.out.println(P1ROLL);
      if (P1ROLL == 6) {
        P1ROLL = ran.nextInt(6) + 1;
        System.out.println(P1ROLL);
      } else {
        break;
      }
      SCORE1 += P1ROLL;
    }
    while (true) {
      P2ROLL = ran.nextInt(6) + 1;
      System.out.println(P2ROLL);
      if (P2ROLL == 6) {
        P2ROLL = ran.nextInt(6) + 1;
        System.out.println(P2ROLL);
      } else {
        break;
      }
      SCORE2 += P1ROLL;
    }*/


  }
}
